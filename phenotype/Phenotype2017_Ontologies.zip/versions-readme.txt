Downloaded on July 7th
HP, MP and DOID from http://www.obofoundry.org/
ORDO from ORPHADATA
MeSH and OMIM from BioPortal
- HP: 2017-06-30 (http://www.obofoundry.org/ontology/hp.html)
- MP: 2017-06-29 (http://www.obofoundry.org/ontology/mp.html)
- DOID: 2017-06-13 (http://www.obofoundry.org/ontology/doid.html)
- ORDO: version 2.4 (http://www.orphadata.org/cgi-bin/inc/ordo_orphanet.inc.php/)
- MeSH: Robert Hoehndorf version 2014 (https://bioportal.bioontology.org/ontologies/RH-MESH)
- OMIM: From UMLS 2016AB (https://bioportal.bioontology.org/ontologies/OMIM)


Baseline mappings extracted from BioPortal
